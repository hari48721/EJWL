<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Search_model extends CI_Model {

	public function __construct()
    {
        $this->load->database();
    }
  
}

/* End of file search_model.php */
/* Location: ./application/models/search_model.php */