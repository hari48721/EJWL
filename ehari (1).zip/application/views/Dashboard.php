<?php include 'inc/header.php'; ?>
<style type="text/css">
	body{
background: url(<?php echo base_url('assets/images/trans.jpg');?>);

}
</style>
<div class="page-header">
	<div class="page-header-content">
		<div class="page-title">

			<h4><i class="icon-arrow-left52 position-left"></i> <span class="text-semibold">Home</span> - ECELECT - Dashboard </h4>
		</div>
		<div class="heading-elements">
			<div class="heading-btn-group">
				<a href="#" class="btn btn-link btn-float has-text"><i class="icon-bars-alt text-primary"></i><span>Statistics</span></a>
				<a href="#" class="btn btn-link btn-float has-text"><i class="icon-calculator text-primary"></i> <span>Invoices</span></a>
				<a href="#" class="btn btn-link btn-float has-text"><i class="icon-calendar5 text-primary"></i> <span>Schedule</span></a>
			</div>
		</div>
	</div>
</div>


	<!--<div class="panel panel-flat">
		
		<div class="panel-body">
			<h4 class="text-center content-group-lg">
				 ECELECT 
				<small class="display-block">Welcome To Waveplus</small>
			</h4>
			<form action="<?=site_url('Dashboard')?>" method="POST">
			<div class="dual-list">
			<div class="input-group content-group">
				<div class="has-feedback has-feedback-left">
					<input type="text" name="SearchDualList" class="form-control input-xlg" placeholder="search" />
					
					<div class="form-control-feedback">
						<i class="icon-search4 text-muted text-size-base"></i>
					</div>
				</div>

				<div class="input-group-btn">
					<button type="submit" class="btn btn-primary btn-xlg">Search</button>
				</div>

</div></div>
</form>-->
	</div>
</div>
</div>

	<script type="text/javascript" src="assets/js/pages/form_bootstrap_select.js"></script>
	<script type="text/javascript" src="assets/js/plugins/forms/selects/bootstrap_select.min.js"></script>
	<!-- Theme JS files
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script> -->



<?php include 'inc/footer.php'; ?>