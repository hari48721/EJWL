</div></div>
<!-- Footer -->
<div class="navbar navbar-default navbar-fixed-bottom footer">
	<ul class="nav navbar-nav visible-xs-block">
		<li><a class="text-center collapsed" data-toggle="collapse" data-target="#footer"><i class="icon-circle-up2"></i></a></li>
	</ul>

	<div class="navbar-collapse collapse" id="footer">
		<div class="navbar-text">
			&copy; 2015. <a href="#" class="navbar-link">Waveplus Softwares</a> Ver 1.0 <a href="http://www.waveplus.in" class="navbar-link" target="_blank"> @ All Rights Reserved </a>
		</div>

		<div class="navbar-right">
			<ul class="nav navbar-nav">
				<li><a href="#">About</a></li>
				<li><a href="#">Terms</a></li>
				<li><a href="#">Contact</a></li>
			</ul>
		</div>
	</div>
</div>
<!-- /footer -->

</body>


</html>
