-- MySQL dump 10.16  Distrib 10.1.9-MariaDB, for Win32 (AMD64)
--
-- Host: localhost    Database: CI_FINA
-- ------------------------------------------------------
-- Server version	10.1.9-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accmaster`
--

DROP TABLE IF EXISTS `accmaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accmaster` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `accName` varchar(100) NOT NULL,
  `SubCode` varchar(100) NOT NULL,
  `tip_own` varchar(100) NOT NULL,
  `OpBal` varchar(100) NOT NULL,
  `OpBalDC` varchar(100) NOT NULL,
  `TINNo` int(20) NOT NULL,
  `CSTNo` int(20) NOT NULL,
  `PANNo` int(20) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `Address1` varchar(100) NOT NULL,
  `State` varchar(100) NOT NULL,
  `City` varchar(100) NOT NULL,
  `zip` int(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accmaster`
--

LOCK TABLES `accmaster` WRITE;
/*!40000 ALTER TABLE `accmaster` DISABLE KEYS */;
INSERT INTO `accmaster` VALUES (1,'Praveen Kumar Accounts','INCOME','','','',0,0,0,'','','','','','',0);
/*!40000 ALTER TABLE `accmaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accsetting`
--

DROP TABLE IF EXISTS `accsetting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accsetting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `DPL` varchar(100) NOT NULL,
  `MPL` varchar(100) NOT NULL,
  `WPL` varchar(100) NOT NULL,
  `HPPL` varchar(100) NOT NULL,
  `TipupL` varchar(100) NOT NULL,
  `IDPL` varchar(100) NOT NULL,
  `IMPL` varchar(100) NOT NULL,
  `IWPL` varchar(100) NOT NULL,
  `IHPPL` varchar(100) NOT NULL,
  `ITipupL` varchar(100) NOT NULL,
  `ML` varchar(100) NOT NULL,
  `IML` varchar(100) NOT NULL,
  `DAC` varchar(100) NOT NULL,
  `IDAC` varchar(100) NOT NULL,
  `DC` varchar(100) NOT NULL,
  `IDE` varchar(100) NOT NULL,
  `AP` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accsetting`
--

LOCK TABLES `accsetting` WRITE;
/*!40000 ALTER TABLE `accsetting` DISABLE KEYS */;
/*!40000 ALTER TABLE `accsetting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `acno`
--

DROP TABLE IF EXISTS `acno`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `acno` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Acno` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acno`
--

LOCK TABLES `acno` WRITE;
/*!40000 ALTER TABLE `acno` DISABLE KEYS */;
/*!40000 ALTER TABLE `acno` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `areacode`
--

DROP TABLE IF EXISTS `areacode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `areacode` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aName` varchar(100) NOT NULL,
  `aCode` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `areacode`
--

LOCK TABLES `areacode` WRITE;
/*!40000 ALTER TABLE `areacode` DISABLE KEYS */;
/*!40000 ALTER TABLE `areacode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cmaster`
--

DROP TABLE IF EXISTS `cmaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmaster` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cName` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `tngst_no` varchar(100) NOT NULL,
  `cst_no` varchar(100) NOT NULL,
  `it_no` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;


DROP TABLE IF EXISTS `itemmaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `itemmaster` (
  `itemcode` int(11) NOT NULL AUTO_INCREMENT,
  `itemName` varchar(100) NOT NULL,
  `catcode` int(11) NOT NULL,
  `salrate` double NOT NULL,
  `wsrate` double NOT NULL,
  `unitname` varchar(20) NOT NULL,
  `itcode` int(11) NOT NULL,
  `wscode` int(11) NOT NULL,
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cmaster`
--

LOCK TABLES `cmaster` WRITE;
/*!40000 ALTER TABLE `cmaster` DISABLE KEYS */;
/*!40000 ALTER TABLE `cmaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `country`
--

DROP TABLE IF EXISTS `country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `country` (
  `countryid` int(11) NOT NULL AUTO_INCREMENT,
  `country` varchar(150) NOT NULL,
  PRIMARY KEY (`countryid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `country`
--

LOCK TABLES `country` WRITE;
/*!40000 ALTER TABLE `country` DISABLE KEYS */;
INSERT INTO `country` VALUES (1,'Madurai'),(2,'Chennai'),(3,'Selam');
/*!40000 ALTER TABLE `country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datatable`
--

DROP TABLE IF EXISTS `datatable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datatable` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `position` varchar(100) NOT NULL,
  `office` varchar(100) NOT NULL,
  `extn` varchar(100) NOT NULL,
  `start_date` datetime NOT NULL,
  `salary` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datatable`
--

LOCK TABLES `datatable` WRITE;
/*!40000 ALTER TABLE `datatable` DISABLE KEYS */;
INSERT INTO `datatable` VALUES (1,'praveen','kumar','programer','head','nothing','2017-10-02 00:00:00','10000');
/*!40000 ALTER TABLE `datatable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dop_payment`
--

DROP TABLE IF EXISTS `dop_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dop_payment` (
  `P_id` int(11) NOT NULL AUTO_INCREMENT,
  `P_AcNo` int(100) NOT NULL,
  `DDate` varchar(100) NOT NULL,
  `DAmt` varchar(100) NOT NULL,
  `DPAmt` varchar(100) NOT NULL,
  `DBAmt` varchar(100) NOT NULL,
  `Total` int(100) NOT NULL,
  `IAmt` varchar(100) NOT NULL,
  `IPAmt` varchar(100) NOT NULL,
  `IBAmt` varchar(100) NOT NULL,
  `RLAmt` varchar(100) NOT NULL,
  `RIAmt` varchar(100) NOT NULL,
  `Parti` varchar(100) NOT NULL,
  PRIMARY KEY (`P_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dop_payment`
--

LOCK TABLES `dop_payment` WRITE;
/*!40000 ALTER TABLE `dop_payment` DISABLE KEYS */;
INSERT INTO `dop_payment` VALUES (5,2,'31/10/2017','4000','2000','2000',2093,'92.05','93.05','92.05','2000','93.05',''),(6,2,'01/11/2017','4000','2000','0',2002,'94.68','1.63','0','2000','1.63',''),(7,1,'02/10/2017','5000','3000','2000',3020,'19.73','19.73','0','3000','19.73',''),(8,1,'31/10/2017','5000','2000','0',2095,'115.07','95.34','0','2000','95.34',''),(9,3,'02/11/2017','5000','3000','2000',3007,'6.58','6.58','0','3000','6.58',''),(10,3,'03/11/2017','5000','2000','0',2003,'9.86','3.28','0','2000','3.28','');
/*!40000 ALTER TABLE `dop_payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dop_receipt`
--

DROP TABLE IF EXISTS `dop_receipt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dop_receipt` (
  `DR_id` int(11) NOT NULL AUTO_INCREMENT,
  `RDate` varchar(100) NOT NULL,
  `op` int(10) NOT NULL,
  `p` int(10) NOT NULL,
  `AcNo` varchar(100) NOT NULL,
  `pcode` varchar(100) NOT NULL,
  `feature` varchar(200) NOT NULL,
  `Amount` int(100) NOT NULL,
  `Interest` int(100) NOT NULL,
  `Doc_detail` varchar(200) NOT NULL,
  PRIMARY KEY (`DR_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dop_receipt`
--

LOCK TABLES `dop_receipt` WRITE;
/*!40000 ALTER TABLE `dop_receipt` DISABLE KEYS */;
INSERT INTO `dop_receipt` VALUES (1,'26/09/2017',0,22,'1','1','',5000,2,''),(2,'26/09/2017',11,0,'2','2','',4000,2,''),(3,'31/10/2017',11,0,'3','3','',5000,2,'');
/*!40000 ALTER TABLE `dop_receipt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gName` varchar(100) NOT NULL,
  `gType` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groups`
--

LOCK TABLES `groups` WRITE;
/*!40000 ALTER TABLE `groups` DISABLE KEYS */;
INSERT INTO `groups` VALUES (1,'interest','Profit And Loss');
/*!40000 ALTER TABLE `groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `links`
--

DROP TABLE IF EXISTS `links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `link1` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `links`
--

LOCK TABLES `links` WRITE;
/*!40000 ALTER TABLE `links` DISABLE KEYS */;
INSERT INTO `links` VALUES (1,'Principal'),(2,'Monthly_Loan'),(3,'Master'),(4,'Party_Master'),(5,'TipUp_Loan'),(6,'Deposit');
/*!40000 ALTER TABLE `links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `links2`
--

DROP TABLE IF EXISTS `links2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `links2` (
  `l_id` int(11) NOT NULL AUTO_INCREMENT,
  `link2` varchar(100) NOT NULL,
  `link1_id` int(100) NOT NULL,
  PRIMARY KEY (`l_id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `links2`
--

LOCK TABLES `links2` WRITE;
/*!40000 ALTER TABLE `links2` DISABLE KEYS */;
INSERT INTO `links2` VALUES (1,'Open_Payment_Entry',1),(2,'Open_Payment_Register',1),(3,'Open_Receipt_Entry',1),(4,'Open_Receipt_register',1),(5,'Payment_Entry',1),(6,'Payment_register',1),(7,'Open_Payment_Entry',2),(8,'Open_Payment_register',2),(9,'Open_Receipt_Entry',2),(10,'Open_Receipt_register',2),(11,'Payment_Entry',2),(12,'Payment_register',2),(13,'Master_Entry',3),(14,'Party_Master_Entry',4),(15,'Region_Master',4),(16,'City_Master',4),(17,'Open_Payment_Entry',5),(18,'Open_Payment_Register',5),(19,'Open_Receipt_Entry',5),(20,'Open_Receipt_register',5),(21,'Payment_Entry',5),(22,'Payment_register',5),(23,'Receipt_Entry',5),(24,'Receipt_register',5),(25,'Groups',3),(26,'Sub_Group',3),(27,'Opening_Balance',3),(28,'Acc_Setting',3),(29,'Open_Receipt_Entry',6),(30,'Open_Receipt_Register',6),(31,'Open_Payment_Entry',6),(32,'Open_Payment_Register',6),(33,'Receipt_Entry',6),(34,'Receipt_register',6),(35,'Payment_Entry',6),(36,'Payment_Register',6),(37,'Pass_book',6),(38,'Outstanding_List',6),(39,'Pass_book',1),(40,'Pass_book',2),(41,'Arrear_List',1),(42,'Outstanding_List',2),(43,'Pass_book',5);
/*!40000 ALTER TABLE `links2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m_payment`
--

DROP TABLE IF EXISTS `m_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `m_payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `MCDate` varchar(100) NOT NULL,
  `AcNo` int(100) NOT NULL,
  `PName` varchar(100) NOT NULL,
  `Parti` varchar(100) NOT NULL,
  `AmountM` int(100) NOT NULL,
  `Docu` int(100) NOT NULL,
  `Intrest` int(100) NOT NULL,
  `AIntrest` int(100) NOT NULL,
  `DocDetail` varchar(100) NOT NULL,
  `payment` int(100) NOT NULL,
  `IAmount` int(100) NOT NULL,
  `Total` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m_payment`
--

LOCK TABLES `m_payment` WRITE;
/*!40000 ALTER TABLE `m_payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `m_payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mop_principal`
--

DROP TABLE IF EXISTS `mop_principal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mop_principal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `op` int(100) NOT NULL,
  `p` int(100) NOT NULL,
  `MCDate` varchar(100) NOT NULL,
  `AcNo` int(100) NOT NULL,
  `PName` varchar(100) NOT NULL,
  `Parti` varchar(100) NOT NULL,
  `AmountM` int(100) NOT NULL,
  `Docu` int(100) NOT NULL,
  `Intrest` int(100) NOT NULL,
  `AIntrest` int(100) NOT NULL,
  `DocDetail` varchar(100) NOT NULL,
  `payment` int(100) NOT NULL,
  `IAmount` int(100) NOT NULL,
  `Total` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mop_principal`
--

LOCK TABLES `mop_principal` WRITE;
/*!40000 ALTER TABLE `mop_principal` DISABLE KEYS */;
INSERT INTO `mop_principal` VALUES (3,11,0,'08/10/2017',1,'Praveen','',5000,0,10,500,'',5500,500,5000);
/*!40000 ALTER TABLE `mop_principal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mop_receipt`
--

DROP TABLE IF EXISTS `mop_receipt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mop_receipt` (
  `R_id` int(11) NOT NULL AUTO_INCREMENT,
  `Rcode` int(100) NOT NULL,
  `RDate` varchar(100) NOT NULL,
  `RAmount` int(100) NOT NULL,
  `BAmount` int(100) NOT NULL,
  `IAmount` int(100) NOT NULL,
  `IRAmount` int(100) NOT NULL,
  `IBAmount` int(100) NOT NULL,
  `ClDate` varchar(100) NOT NULL,
  `RLAmount` int(100) NOT NULL,
  `RIAmount` int(100) NOT NULL,
  `Parti` varchar(100) NOT NULL,
  PRIMARY KEY (`R_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mop_receipt`
--

LOCK TABLES `mop_receipt` WRITE;
/*!40000 ALTER TABLE `mop_receipt` DISABLE KEYS */;
INSERT INTO `mop_receipt` VALUES (1,1,'08/10/2017',5000,0,0,500,0,'',0,0,''),(2,1,'08/25/2017',0,0,0,0,0,'',0,0,'');
/*!40000 ALTER TABLE `mop_receipt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `op_principal`
--

DROP TABLE IF EXISTS `op_principal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `op_principal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `op` int(100) NOT NULL,
  `p` int(100) NOT NULL,
  `Terms` varchar(100) NOT NULL,
  `LDate` date NOT NULL,
  `AcNo` varchar(100) NOT NULL,
  `PName` varchar(100) NOT NULL,
  `Monthly` varchar(100) NOT NULL,
  `Maturity` varchar(100) NOT NULL,
  `Amount` varchar(100) NOT NULL,
  `Intrest` varchar(100) NOT NULL,
  `Due` varchar(100) NOT NULL,
  `Colc` varchar(100) NOT NULL,
  `Parti` varchar(100) NOT NULL,
  `DocAmt` varchar(100) NOT NULL,
  `DocDl` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `op_principal`
--

LOCK TABLES `op_principal` WRITE;
/*!40000 ALTER TABLE `op_principal` DISABLE KEYS */;
INSERT INTO `op_principal` VALUES (1,11,0,'D','2017-11-28','1','Praveen','2','30/11/2017','5000','100','2500.00','2500.00','','',''),(2,11,0,'W','2017-11-30','2','Naveen','4','28/12/2017','6000','100','1500.00','1500.00','','',''),(3,11,0,'M','2017-11-29','3','Kumar','2','29/01/2018','10000','1000','5000.00','5000.00','','','');
/*!40000 ALTER TABLE `op_principal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `op_receipt`
--

DROP TABLE IF EXISTS `op_receipt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `op_receipt` (
  `R_id` int(11) NOT NULL AUTO_INCREMENT,
  `Rcode` int(100) NOT NULL,
  `RCDate` date NOT NULL,
  `RAmount` varchar(100) NOT NULL,
  `BAmount` varchar(100) NOT NULL,
  `AAmount` varchar(100) NOT NULL,
  `payAmount` varchar(100) NOT NULL,
  PRIMARY KEY (`R_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `op_receipt`
--

LOCK TABLES `op_receipt` WRITE;
/*!40000 ALTER TABLE `op_receipt` DISABLE KEYS */;
INSERT INTO `op_receipt` VALUES (1,1,'2017-11-29','1000','4000','4000','1000'),(2,1,'2017-11-30','4000','0','0','4000');
/*!40000 ALTER TABLE `op_receipt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `op_receipt2`
--

DROP TABLE IF EXISTS `op_receipt2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `op_receipt2` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Terms` varchar(100) NOT NULL,
  `RCDate` varchar(100) NOT NULL,
  `AcNo` varchar(100) NOT NULL,
  `VcNo` int(100) NOT NULL,
  `Pname` varchar(100) NOT NULL,
  `LDate` varchar(100) NOT NULL,
  `LAmount` varchar(100) NOT NULL,
  `RAmount` varchar(100) NOT NULL,
  `BAmount` varchar(100) NOT NULL,
  `AAmount` varchar(100) NOT NULL,
  `ClDate` varchar(100) NOT NULL,
  `DAmount` varchar(100) NOT NULL,
  `DDate` varchar(100) NOT NULL,
  `payAmount` varchar(100) NOT NULL,
  `InLAmount` varchar(100) NOT NULL,
  `Parti` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `op_receipt2`
--

LOCK TABLES `op_receipt2` WRITE;
/*!40000 ALTER TABLE `op_receipt2` DISABLE KEYS */;
/*!40000 ALTER TABLE `op_receipt2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `parmaster`
--

DROP TABLE IF EXISTS `parmaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `parmaster` (
  `pcode` int(11) NOT NULL AUTO_INCREMENT,
  `PName` varchar(100) NOT NULL,
  `Phone` varchar(100) NOT NULL,
  `Mobile` varchar(100) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Address2` varchar(100) NOT NULL,
  `State` varchar(100) NOT NULL,
  `Area` varchar(100) NOT NULL,
  `City` varchar(100) NOT NULL,
  `Zipcode` varchar(100) NOT NULL,
  PRIMARY KEY (`pcode`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parmaster`
--

LOCK TABLES `parmaster` WRITE;
/*!40000 ALTER TABLE `parmaster` DISABLE KEYS */;
INSERT INTO `parmaster` VALUES (1,'Praveen','9889898989','','','','','2','1',''),(2,'Naveen','9839338439','','','','','3','2',''),(4,'Kumar','8484588458','','','','','5','3','625003');
/*!40000 ALTER TABLE `parmaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `php_table`
--

DROP TABLE IF EXISTS `php_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `php_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `php_table`
--

LOCK TABLES `php_table` WRITE;
/*!40000 ALTER TABLE `php_table` DISABLE KEYS */;
INSERT INTO `php_table` VALUES (1,' \n           \n          praveenSS','Kumar'),(2,' \n           \n          HariS        ','SSS');
/*!40000 ALTER TABLE `php_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `principal`
--

DROP TABLE IF EXISTS `principal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `principal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Terms` varchar(100) NOT NULL,
  `CDate` varchar(100) NOT NULL,
  `AcNo` varchar(100) NOT NULL,
  `Pname` varchar(100) NOT NULL,
  `Months` varchar(100) NOT NULL,
  `Weekly` varchar(100) NOT NULL,
  `Dailly` varchar(100) NOT NULL,
  `MaturityM` varchar(100) NOT NULL,
  `MaturityW` varchar(100) NOT NULL,
  `MaturityD` varchar(100) NOT NULL,
  `AmountM` varchar(100) NOT NULL,
  `AmountW` varchar(100) NOT NULL,
  `AmountD` varchar(100) NOT NULL,
  `Intrest` varchar(100) NOT NULL,
  `Due` varchar(100) NOT NULL,
  `Colc` varchar(100) NOT NULL,
  `Parti` varchar(100) NOT NULL,
  `DocAmount` varchar(100) NOT NULL,
  `DocDetail` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `principal`
--

LOCK TABLES `principal` WRITE;
/*!40000 ALTER TABLE `principal` DISABLE KEYS */;
/*!40000 ALTER TABLE `principal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `receipt`
--

DROP TABLE IF EXISTS `receipt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `receipt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Terms` varchar(100) NOT NULL,
  `RCDate` varchar(100) NOT NULL,
  `AcNo` varchar(100) NOT NULL,
  `Pname` varchar(100) NOT NULL,
  `LDate` varchar(100) NOT NULL,
  `LAmount` varchar(100) NOT NULL,
  `RAmount` varchar(100) NOT NULL,
  `BAmount` varchar(100) NOT NULL,
  `AAmount` varchar(100) NOT NULL,
  `ClDate` varchar(100) NOT NULL,
  `DAmount` varchar(100) NOT NULL,
  `DDate` varchar(100) NOT NULL,
  `payAmount` varchar(100) NOT NULL,
  `InLAmount` varchar(100) NOT NULL,
  `Parti` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `receipt`
--

LOCK TABLES `receipt` WRITE;
/*!40000 ALTER TABLE `receipt` DISABLE KEYS */;
/*!40000 ALTER TABLE `receipt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `state`
--

DROP TABLE IF EXISTS `state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `state` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `statename` varchar(30) NOT NULL,
  `countryid` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `state`
--

LOCK TABLES `state` WRITE;
/*!40000 ALTER TABLE `state` DISABLE KEYS */;
INSERT INTO `state` VALUES (2,'BB KULAM',1),(3,'K K Nager',2),(4,'Main Road',3),(5,'Bus stand op',3),(6,'Anna Nagar',1);
/*!40000 ALTER TABLE `state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subgroup`
--

DROP TABLE IF EXISTS `subgroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subgroup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subName` varchar(100) NOT NULL,
  `gName` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subgroup`
--

LOCK TABLES `subgroup` WRITE;
/*!40000 ALTER TABLE `subgroup` DISABLE KEYS */;
INSERT INTO `subgroup` VALUES (1,'INCOME','INCOME'),(2,'Profit','Profit and Loss');
/*!40000 ALTER TABLE `subgroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipup`
--

DROP TABLE IF EXISTS `tipup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipup` (
  `TipUp_id` int(100) NOT NULL,
  `Tname` varchar(200) NOT NULL,
  `TAmount` int(100) NOT NULL,
  `Per` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipup`
--

LOCK TABLES `tipup` WRITE;
/*!40000 ALTER TABLE `tipup` DISABLE KEYS */;
INSERT INTO `tipup` VALUES (1,'Praveen Madurai',1500,30),(1,'kumar Madurai',1500,30),(1,'ManiMaran ',2000,40),(2,'Praveen Madurai',2000,50),(2,'kumar Madurai',2000,50);
/*!40000 ALTER TABLE `tipup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipup_details`
--

DROP TABLE IF EXISTS `tipup_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipup_details` (
  `TieUp_id` int(100) NOT NULL,
  `Tname` varchar(200) NOT NULL,
  `TAmount` int(100) NOT NULL,
  `Per` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipup_details`
--

LOCK TABLES `tipup_details` WRITE;
/*!40000 ALTER TABLE `tipup_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `tipup_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipup_payment`
--

DROP TABLE IF EXISTS `tipup_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipup_payment` (
  `Tid` int(11) NOT NULL AUTO_INCREMENT,
  `op` int(100) NOT NULL,
  `p` int(100) NOT NULL,
  `TDate` varchar(100) NOT NULL,
  `TAcNo` int(100) NOT NULL,
  `TName` varchar(100) NOT NULL,
  `TPart` varchar(100) NOT NULL,
  `TAmt` int(100) NOT NULL,
  `TDDate` varchar(100) NOT NULL,
  `TMode` int(10) NOT NULL,
  `TNDue` int(10) NOT NULL,
  `TDAmt` int(10) NOT NULL,
  `TDCh` int(100) NOT NULL,
  `TInt` int(10) NOT NULL,
  `TInAmt` int(100) NOT NULL,
  `TTotal` int(100) NOT NULL,
  `TAddress` varchar(100) NOT NULL,
  `TDDat` varchar(100) NOT NULL,
  PRIMARY KEY (`Tid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipup_payment`
--

LOCK TABLES `tipup_payment` WRITE;
/*!40000 ALTER TABLE `tipup_payment` DISABLE KEYS */;
INSERT INTO `tipup_payment` VALUES (1,11,0,'31/10/2017',1,'1','',5000,'2/11/2017',2,3,1667,0,2,100,4900,'',''),(2,11,0,'02/11/2017',2,'2','',4000,'6/11/2017',4,2,2000,0,2,80,3920,'','');
/*!40000 ALTER TABLE `tipup_payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipup_receipt`
--

DROP TABLE IF EXISTS `tipup_receipt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipup_receipt` (
  `TRid` int(11) NOT NULL AUTO_INCREMENT,
  `op` int(2) NOT NULL,
  `p` int(2) NOT NULL,
  `TRAcNo` int(100) NOT NULL,
  `TRDate` varchar(100) NOT NULL,
  `TRBAmt` int(100) NOT NULL,
  `TRRAmt` int(100) NOT NULL,
  `TRAAmt` int(100) NOT NULL,
  `TRNA` int(100) NOT NULL,
  PRIMARY KEY (`TRid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipup_receipt`
--

LOCK TABLES `tipup_receipt` WRITE;
/*!40000 ALTER TABLE `tipup_receipt` DISABLE KEYS */;
INSERT INTO `tipup_receipt` VALUES (1,11,0,1,'25/10/2017',3750,1250,3750,4);
/*!40000 ALTER TABLE `tipup_receipt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (4,'wave','55');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-05 19:06:12
